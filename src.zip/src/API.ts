import { skiEquipmentsData } from './app/ski-equipments';
import { SkidItem } from './app/entities/skid-paket';
