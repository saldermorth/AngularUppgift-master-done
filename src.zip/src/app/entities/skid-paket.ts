export interface SkidItem {
  id: number;
  header: string;
  description: string;
  extendedDescription: string;
  imageUrl: string;
}
