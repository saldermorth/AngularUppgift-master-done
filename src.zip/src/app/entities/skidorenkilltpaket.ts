export class Skidorenkilltpaket {
}
