export interface Bokningscomfirm {
  confirmationNumber: string;
}
